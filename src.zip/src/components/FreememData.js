import React, {useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function FreememData() {
    const {freememData} = useContext(MainContext);
    useEffect(() => {
    }, [freememData])

    return (

        <div className="col-md-4">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>Freemem</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            freememData !== null ?

                                <tr>
                                    <td>{decodeMorse(freememData.checksum)}</td>
                                    <td>{decodeMorse(freememData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>

    );
}

export default FreememData;