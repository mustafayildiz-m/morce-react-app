import React, {useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function PlatformData() {
    const {platformData} = useContext(MainContext);
    useEffect(() => {
    }, [platformData])


    return (

        <div className="col-md-3">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>Platform</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            platformData !== null ?

                                <tr>
                                    <td>{decodeMorse(platformData.checksum)}</td>
                                    <td>{decodeMorse(platformData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>

    );
}

export default PlatformData;