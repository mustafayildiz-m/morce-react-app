import React from 'react';
import {useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function HostNameData() {
    const {hostnameData} = useContext(MainContext);
    useEffect(() => {
    }, [hostnameData])

    return (
        <div className="col-md-4">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>Hostname</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            hostnameData !== null ?

                                <tr>
                                    <td>{decodeMorse(hostnameData.checksum)}</td>
                                    <td>{decodeMorse(hostnameData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>
    );
}

export default HostNameData;