import React,{useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function TotalmemData() {
    const {totalmemData} = useContext(MainContext);
    useEffect(() => {
    }, [totalmemData])

    return (

        <div className="col-md-3">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>Totalmem</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            totalmemData !== null ?

                                <tr>
                                    <td>{decodeMorse(totalmemData.checksum)}</td>
                                    <td>{decodeMorse(totalmemData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>

    );
}

export default TotalmemData;