import React,{useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function TypeData() {
    const {typeData} = useContext(MainContext);
    useEffect(() => {
    }, [typeData])

    return (

        <div className="col-md-3">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>TypeData</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            typeData !== null ?

                                <tr>
                                    <td>{decodeMorse(typeData.checksum)}</td>
                                    <td>{decodeMorse(typeData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>

    );
}

export default TypeData;