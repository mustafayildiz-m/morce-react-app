import React, {useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function ArchData() {

    const {archData} = useContext(MainContext);
    useEffect(() => {
    }, [archData])

    return (
        <div className="col-md-4">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>Arch</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            archData !== null ?

                                <tr>
                                    <td>{decodeMorse(archData.checksum)}</td>
                                    <td>{decodeMorse(archData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>

        </div>




    );
}

export default ArchData;