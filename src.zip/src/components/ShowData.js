import React, {useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function ShowData() {

    const {morseData} = useContext(MainContext);

    useEffect(() => {
    }, [morseData])


    return (
        <React.Fragment>

            <div className="container mt-5 mt-auto">
                <div className="card">
                    <div className="card-header">
                        <h1 style={{textAlign:"center"}}>CPU</h1>
                    </div>

                    <div className="card-body">
                        <Table hover striped>
                            <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Model
                                </th>
                                <th>
                                    Speed
                                </th>
                                <th>
                                    Times
                                </th>

                            </tr>
                            </thead>
                            <tbody>

                            {
                                morseData ?
                                    morseData.data.map((item, key) => (
                                            <tr key={key}>
                                                <td scope="row">
                                                    {key}
                                                </td>
                                                <td>
                                                    {decodeMorse(item.model)}
                                                </td>
                                                <td>
                                                    {decodeMorse(item.speed)}
                                                </td>
                                                <td>
                                                    <ul>
                                                        <li>idle : {decodeMorse(item.times.idle)}</li>
                                                        <li>irq : {decodeMorse(item.times.irq)}</li>
                                                        <li>nice : {decodeMorse(item.times.nice)}</li>
                                                        <li>sys : {decodeMorse(item.times.sys)}</li>
                                                        <li>user : {decodeMorse(item.times.user)}</li>
                                                    </ul>
                                                </td>

                                            </tr>
                                        )
                                    )
                                    : null}




                            </tbody>
                        </Table>
                    </div>
                </div>

            </div>


        </React.Fragment>
    );
}

export default ShowData;