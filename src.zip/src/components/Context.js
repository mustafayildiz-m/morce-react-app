import {useContext, createContext} from "react";

const MainContext = createContext();

export {
    MainContext, useContext
}