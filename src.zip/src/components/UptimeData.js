import React,{useEffect} from 'react';
import {MainContext, useContext} from "./Context";
import {decodeMorse} from "./MorsecodeTranslator";
import {Table} from "reactstrap";

function UptimeData() {
    const {uptimeData} = useContext(MainContext);
    useEffect(() => {
    }, [uptimeData])

    return (

        <div className="col-md-3">
            <div className="card">
                <div className="card-header">
                    <h5 style={{textAlign: "center"}}>UptimeData</h5>
                </div>

                <div className="card-body">
                    <Table hover striped>
                        <thead>
                        <tr>

                            <th>
                                checksum
                            </th>
                            <th>
                                data
                            </th>

                        </tr>
                        </thead>
                        <tbody>

                        {
                            uptimeData !== null ?

                                <tr>
                                    <td>{decodeMorse(uptimeData.checksum)}</td>
                                    <td>{decodeMorse(uptimeData.data)}</td>
                                </tr>
                                : null

                        }


                        </tbody>
                    </Table>
                </div>
            </div>
        </div>

    );
}

export default UptimeData;