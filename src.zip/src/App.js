import React from "react";
import {useState, useEffect} from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import {MainContext} from "./components/Context";
import axios from "axios";
import ShowData from "./components/ShowData";
import ArchData from "./components/ArchData";
import FreememData from "./components/FreememData";
import HostNameData from "./components/HostNameData";
import UptimeData from "./components/UptimeData";
import TypeData from "./components/TypeData";
import TotalmemData from "./components/TotalmemData";
import PlatformData from "./components/PlatformData";

function App() {


    const [morseData, setMorseData] = useState(null);
    const [archData, setArchData] = useState(null);
    const [freememData, setFreemem] = useState(null);
    const [hostnameData, setHostname] = useState(null);
    const [platformData, setPlatform] = useState(null);
    const [totalmemData, setTotalmemform] = useState(null);
    const [typeData, setType] = useState(null);
    const [uptimeData, setUptime] = useState(null);


    const getData = async () => {
        let postData = {
            "command": "-.-. .--. ..-"
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setMorseData(response.data)
                })


        } catch {
            console.log("cpu error")
        }
    }


    //return arch data
    const getArc = async () => {
        let postData = {
            "command": ".- .-. -.-. ...."
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setArchData(response.data)
                })


        } catch {
            console.log("getArch error")
        }
    }

    //return arch Freemem data
    const getFreemem = async () => {
        let postData = {
            "command": "..-. .-. . . -- . --"
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setFreemem(response.data)
                })


        } catch {
            console.log("getFreemem error")
        }
    }


    //return HOSTNAME Freemem data
    const getHostname = async () => {
        let postData = {
            "command": ".... --- ... - -. .- -- ."
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setHostname(response.data)
                })


        } catch {
            console.log("getHostname error")
        }
    }

    //return platform Freemem data
    const getPLatformData = async () => {
        let postData = {
            "command": ".--. .-.. .- - ..-. --- .-. --"
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setPlatform(response.data)
                })


        } catch {
            console.log("getPLatformData error")
        }
    }


    //return totalmem Freemem data
    const getTotalmemData = async () => {
        let postData = {
            "command": "- --- - .- .-.. -- . --"
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setTotalmemform(response.data)
                })


        } catch {
            console.log("getTotalmemData error")
        }
    }


    //return type data
    const getTypeData = async () => {
        let postData = {
            "command": "- -.-- .--. ."
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setType(response.data)
                })


        } catch {
            console.log("getTypeData error")
        }
    }


    //return type Uptime data
    const getUptimeData = async () => {
        let postData = {
            "command": "..- .--. - .. -- ."
        }
        try {
            await axios.post('http://ik.olleco.net/morse-api/', postData)
                .then(response => {
                    response.data && setUptime(response.data)
                })


        } catch {
            console.log("getUptimeData error")
        }
    }


    useEffect(() => {
        getData()
        getArc()
        getFreemem()
        getHostname()
        getPLatformData()
        getTotalmemData()
        getTypeData()
        getUptimeData()


    }, [morseData, archData, freememData, hostnameData, totalmemData, typeData, platformData, uptimeData])


    const propsData = {
        morseData,
        archData,
        freememData, hostnameData,
        platformData, totalmemData, typeData, uptimeData
    }

    return (
        <MainContext.Provider value={propsData}>
            <ShowData/>

            <div className="container mt-5 mt-auto">
                <div className="row">
                    <ArchData/>
                    <FreememData/>
                    <HostNameData/>
                </div>
                <div className="row">
                    <UptimeData/>
                    <TypeData/>
                    <TotalmemData/>
                    <PlatformData/>
                </div>
            </div>


        </MainContext.Provider>
    );
}

export default App;
